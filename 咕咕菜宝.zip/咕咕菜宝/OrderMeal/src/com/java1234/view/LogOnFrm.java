/*
 * LogOnFrm.java
 *
 * 
 */

package com.java1234.view;

import java.awt.Font;
import java.sql.Connection;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

import com.java1234.dao.UserDao;
import com.java1234.model.User;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;

/**
 *
 * @author ����
 * ��½����
 */
public class LogOnFrm extends javax.swing.JFrame {

	DbUtil dbUtil = new DbUtil();
	UserDao userDao = new UserDao();
	public static User s_currentUser = null;//�����½�û��Ĳ���

	/** Creates new form LogOnFrm */
	public LogOnFrm() {
		//�ı�ϵͳĬ������
		Font font = new Font("Dialog", Font.PLAIN, 12);
		java.util.Enumeration keys = UIManager.getDefaults().keys();
		while (keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof javax.swing.plaf.FontUIResource) {
				UIManager.put(key, font);
			}
		}
		initComponents();
		//����frame������ʾ
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jb_logon = new javax.swing.JButton();
		jb_register = new javax.swing.JButton();
		userNameTxt = new javax.swing.JTextField();
		passwordTxt = new javax.swing.JPasswordField();
		jb_reset = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("\u9910\u5385\u70b9\u9910\u7cfb\u7edf");
		setResizable(false);

		jLabel1.setFont(new java.awt.Font("����", 1, 24));
		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/OrderMeal.png"))); // NOI18N
		jLabel1
				.setText("\u5495\u5495\u83DC\u5B9D");

		jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/userName.png"))); // NOI18N
		jLabel2.setText("\u7528\u6237\u540d\uff1a");

		jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/password.png"))); // NOI18N
		jLabel3.setText("\u5bc6  \u7801\uff1a");

		jb_logon.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/login.png"))); // NOI18N
		jb_logon.setText("\u767b\u9646");
		jb_logon.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_logonActionPerformed(evt);
			}
		});

		jb_register.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/register.png"))); // NOI18N
		jb_register.setText("\u6ce8\u518c\u7528\u6237");
		jb_register.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_registerActionPerformed(evt);
			}
		});

		jb_reset.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/reset.png"))); // NOI18N
		jb_reset.setText("\u91cd\u7f6e");
		jb_reset.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_resetActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		layout.setHorizontalGroup(
			layout.createParallelGroup(Alignment.TRAILING)
				.addGroup(layout.createSequentialGroup()
					.addGap(52)
					.addGroup(layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(jLabel2)
								.addComponent(jLabel3))
							.addGap(33)
							.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(passwordTxt)
								.addComponent(userNameTxt, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)))
						.addGroup(layout.createSequentialGroup()
							.addGap(8)
							.addComponent(jb_logon)
							.addGap(18)
							.addComponent(jb_reset)
							.addGap(18)
							.addComponent(jb_register)))
					.addContainerGap(59, Short.MAX_VALUE))
				.addGroup(layout.createSequentialGroup()
					.addContainerGap(106, Short.MAX_VALUE)
					.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 304, GroupLayout.PREFERRED_SIZE))
		);
		layout.setVerticalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGap(27)
					.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(jLabel2)
						.addComponent(userNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(38)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(jLabel3)
						.addComponent(passwordTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(37)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(jb_logon)
						.addComponent(jb_reset)
						.addComponent(jb_register))
					.addContainerGap(55, Short.MAX_VALUE))
		);
		getContentPane().setLayout(layout);

		pack();
	}// </editor-fold>
	//GEN-END:initComponents
    
	//��ʾע��ҳ��
	private void jb_registerActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		new RegisterFrm().setVisible(true);
	}
	//��½��֤��ʾ��½�Ժ����
	private void jb_logonActionPerformed(java.awt.event.ActionEvent evt) {
		String userName = this.userNameTxt.getText();
		String password = new String(this.passwordTxt.getPassword());
		if (StringUtil.isEmpty(userName)) {
			JOptionPane.showMessageDialog(null, "�û�������Ϊ��");
			return;
		}
		if (StringUtil.isEmpty(password)) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��");
			return;
		}
		User user = new User(userName, password);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			User currentUser = userDao.login(con, user);
			if (currentUser != null) {
				s_currentUser = currentUser;//�����½���û�
				int role = currentUser.getRank();
				if (role == 1) {
					this.dispose();
					new AdminFrm().setVisible(true);//�������Աҳ��
				} else if (role == 0) {
					this.dispose();
					new UserOrderFrm().setVisible(true);//�����û���ͽ���
				}
			} else {
				JOptionPane.showMessageDialog(null, "�û������������");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "�û������������");
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	//�����ı�������
	private void jb_resetActionPerformed(java.awt.event.ActionEvent evt) {
		this.passwordTxt.setText("");
		this.userNameTxt.setText("");
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new LogOnFrm().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JButton jb_logon;
	private javax.swing.JButton jb_register;
	private javax.swing.JButton jb_reset;
	private javax.swing.JPasswordField passwordTxt;
	private javax.swing.JTextField userNameTxt;
	// End of variables declaration//GEN-END:variables

}
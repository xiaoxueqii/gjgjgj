/*
 * GoodsManageInterFrm.java
 *
 *  
 */

package com.java1234.view;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.GoodsDao;
import com.java1234.model.Goods;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

/**
 *
 * @author  ����
 * �ײ���Ϣ�޸Ľ���
 */
public class GoodsManageInterFrm extends javax.swing.JInternalFrame {
	DbUtil dbUtil = new DbUtil();
	GoodsDao goodsDao = new GoodsDao();

	/** Creates new form GoodsManageInterFrm */
	public GoodsManageInterFrm() {
		initComponents();
		this.setLocation(320, 100);
		this.filltable(new Goods());
	}

	//���table����,ˢ������
	private void filltable(Goods goods) {
		DefaultTableModel dtm = (DefaultTableModel) goodsTable.getModel();
		//���֮ǰ��ʾ
		dtm.setRowCount(0);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			ResultSet rs = goodsDao.goodsList(con, goods);
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString("id"));
				v.add(rs.getString("goodsName"));
				v.add(rs.getString("goodsDesc"));
				v.add(rs.getString("price"));
				v.add(rs.getString("imageLink"));
				dtm.addRow(v);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jButton1 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jb_search = new javax.swing.JButton();
		s_goodsName = new javax.swing.JTextField();
		s_price_1 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		goodsTable = new javax.swing.JTable();
		jPanel1 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		goodsNameTxt = new javax.swing.JTextField();
		priceTxt = new javax.swing.JTextField();
		jScrollPane2 = new javax.swing.JScrollPane();
		goodsDescTxt = new javax.swing.JTextArea();
		jLabel6 = new javax.swing.JLabel();
		imageLinkTxt = new javax.swing.JTextField();
		jPanel2 = new javax.swing.JPanel();
		iamgeLb = new javax.swing.JLabel();
		jb_modify = new javax.swing.JButton();
		jb_delete = new javax.swing.JButton();
		jb_chooser = new javax.swing.JButton();
		jLabel7 = new javax.swing.JLabel();
		goodsIdTxt = new javax.swing.JTextField();
		s_price_2 = new javax.swing.JTextField();
		jLabel8 = new javax.swing.JLabel();

		jButton1.setText("jButton1");

		setClosable(true);
		setIconifiable(true);
		setTitle("\u5957\u9910\u4fe1\u606f\u7ef4\u62a4");

		jLabel1.setText("\u5957\u9910\u540d\u79f0\uff1a");

		jb_search.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/search.png"))); // NOI18N
		jb_search.setText("\u67e5\u8be2");
		jb_search.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_searchActionPerformed(evt);
			}
		});

		jLabel2.setText("\u5957\u9910\u4ef7\u683c\u533a\u95f4\uff1a");

		goodsTable.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] {

				}, new String[] { "���", "�ײ�����", "�ײ�����", "�ײͼ۸�", "ͼƬ��ַ" }) {
			boolean[] canEdit = new boolean[] { false, false, false, false,
					false };

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		});
		goodsTable.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mousePressed(java.awt.event.MouseEvent evt) {
				goodsTableMousePressed(evt);
			}
		});
		jScrollPane1.setViewportView(goodsTable);

		jPanel1.setBorder(javax.swing.BorderFactory
				.createTitledBorder("\u8868\u5355\u64cd\u4f5c"));

		jLabel3.setText("\u5957\u9910\u540d\u79f0\uff1a");

		jLabel4.setText("\u5957\u9910\u4ef7\u683c\uff1a");

		jLabel5.setText("\u5957\u9910\u63cf\u8ff0\uff1a");

		goodsDescTxt.setColumns(20);
		goodsDescTxt.setRows(5);
		jScrollPane2.setViewportView(goodsDescTxt);

		jLabel6.setText("\u5957\u9910\u56fe\u7247\uff1a");

		imageLinkTxt.setEnabled(false);

		jPanel2.setBorder(javax.swing.BorderFactory
				.createTitledBorder("\u5957\u9910\u56fe\u7247"));

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(iamgeLb,
								javax.swing.GroupLayout.PREFERRED_SIZE, 60,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addComponent(iamgeLb,
						javax.swing.GroupLayout.PREFERRED_SIZE, 60,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		jb_modify.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/modify.png"))); // NOI18N
		jb_modify.setText("\u4fee\u6539");
		jb_modify.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_modifyActionPerformed(evt);
			}
		});

		jb_delete.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/delete.png"))); // NOI18N
		jb_delete.setText("\u5220\u9664");
		jb_delete.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_deleteActionPerformed(evt);
			}
		});

		jb_chooser.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/images/2.png"))); // NOI18N
		jb_chooser.setText("\u8bf7\u9009\u62e9");
		jb_chooser.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jb_chooserActionPerformed(evt);
			}
		});

		jLabel7.setText("\u7f16\u53f7\uff1a");

		goodsIdTxt.setEditable(false);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addComponent(jLabel3)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(goodsNameTxt,javax.swing.GroupLayout.PREFERRED_SIZE,76,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(18,18,18)
						.addComponent(jLabel4)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(priceTxt,javax.swing.GroupLayout.PREFERRED_SIZE,59,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jLabel7)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(goodsIdTxt,javax.swing.GroupLayout.PREFERRED_SIZE,46,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(37,37,37)
						.addComponent(jLabel6))
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addComponent(jLabel5)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jScrollPane2,javax.swing.GroupLayout.PREFERRED_SIZE,373,javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING,false)
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,jPanel1Layout.createSequentialGroup()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
						.addComponent(jPanel2,javax.swing.GroupLayout.PREFERRED_SIZE,85,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(jb_modify))
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jb_delete,javax.swing.GroupLayout.Alignment.TRAILING)
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addGap(30,30,30)
						.addComponent(jb_chooser))))
						.addComponent(imageLinkTxt,javax.swing.GroupLayout.PREFERRED_SIZE,214,javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addGap(20, 20, 20)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jLabel3)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
						.addComponent(goodsNameTxt,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(jLabel4)
						.addComponent(priceTxt,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(jLabel7)
						.addComponent(jLabel6)
						.addComponent(imageLinkTxt,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(goodsIdTxt,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addGap(33, 33, 33)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jLabel5)
						.addComponent(jb_chooser))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,96,	Short.MAX_VALUE)
						.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
						.addComponent(jb_delete)
						.addComponent(jb_modify)))
						.addComponent(jScrollPane2,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(jPanel2,javax.swing.GroupLayout.PREFERRED_SIZE,87,javax.swing.GroupLayout.PREFERRED_SIZE))
						.addContainerGap()));

		jLabel8.setText("\u2014\u2014");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						                .addGroup(layout.createSequentialGroup()
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(layout.createSequentialGroup()
										.addGap(51,51,51)
										.addComponent(jLabel1)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(s_goodsName,javax.swing.GroupLayout.PREFERRED_SIZE,137,
										javax.swing.GroupLayout.PREFERRED_SIZE).addGap(18,18,18)
										.addComponent(jLabel2)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(s_price_1,javax.swing.GroupLayout.PREFERRED_SIZE,68,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(2,2,2)
										.addComponent(jLabel8)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(s_price_2,javax.swing.GroupLayout.PREFERRED_SIZE,66,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(33,33,33)
										.addComponent(jb_search))
										.addGroup(layout.createSequentialGroup()
										.addContainerGap()
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
										.addComponent(jPanel1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jScrollPane1,javax.swing.GroupLayout.PREFERRED_SIZE,737,javax.swing.GroupLayout.PREFERRED_SIZE))))
										.addContainerGap(128, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,layout.createSequentialGroup()
										.addContainerGap(44, Short.MAX_VALUE)
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(jLabel1)
										.addComponent(s_goodsName,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jLabel2)
										.addComponent(s_price_2,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(s_price_1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jLabel8)
										.addComponent(jb_search))
										.addGap(27, 27, 27)
										.addComponent(jScrollPane1,javax.swing.GroupLayout.PREFERRED_SIZE,122,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jPanel1,javax.swing.GroupLayout.PREFERRED_SIZE,javax.swing.GroupLayout.DEFAULT_SIZE,javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	/**
	 * @param evt
	 */
	//�޸Ĳ���
	private void jb_modifyActionPerformed(java.awt.event.ActionEvent evt) {
		String id = this.goodsIdTxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫ�޸ĵļ�¼");
			return;
		}
		String goodsName = this.goodsNameTxt.getText();
		String goodsDesc = this.goodsDescTxt.getText();
		String imageLink = this.imageLinkTxt.getText();
		String price = this.priceTxt.getText();
		if (StringUtil.isEmpty(goodsName)) {
			JOptionPane.showMessageDialog(null, "�ײ����Ʋ���Ϊ��");
			return;
		}
		if (StringUtil.isEmpty(price)) {
			JOptionPane.showMessageDialog(null, "�ײͼ۸���Ϊ��");
			return;
		}
		if (!StringUtil.isNum(price)) {
			JOptionPane.showMessageDialog(null, "�����������ײͼ۸�");
			return;
		}
		Goods goods = new Goods(Integer.parseInt(id), goodsName, goodsDesc,
				Float.parseFloat(price), imageLink);
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int modifyNum = goodsDao.goodsModify(con, goods);
			if (modifyNum == 1) {
				JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
				this.filltable(new Goods());//
				resetValues();
			} else
				JOptionPane.showMessageDialog(null, "�޸�ʧ��");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "�޸�ʧ��");
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	//ɾ������
	private void jb_deleteActionPerformed(java.awt.event.ActionEvent evt) {
		String id = this.goodsIdTxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(null, "��ѡ��Ҫɾ���ļ�¼");
			return;
		}
		int n = JOptionPane.showConfirmDialog(null, "ȷ��Ҫɾ��������¼��");
		if (n == 0) {
			Connection con = null;
			try {
				con = dbUtil.getCon();
				int deleteNum = goodsDao.goodsDelete(con, id);
				if (deleteNum == 1) {
					JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
					this.filltable(new Goods());
					resetValues();
				} else
					JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
			} catch (Exception e) {

				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "ɾ��ʧ��");
			} finally {
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}

	//ѡ��ͼƬ
	private void jb_chooserActionPerformed(java.awt.event.ActionEvent evt) {
		JFileChooser chooser = new JFileChooser();//�����ļ��Ի���
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"JPG & GIF Images", "jpg", "gif");//�����ļ�������
		chooser.setFileFilter(filter);//Ϊ�ļ��Ի��������ļ�������
		int returnValue = chooser.showOpenDialog(getParent());//���ļ�ѡ��Ի���
		if (returnValue == JFileChooser.APPROVE_OPTION) { // �ж��Ƿ�ѡ�����ļ�
			File file = chooser.getSelectedFile(); // ����ļ�����
			if (file.length() / 1024.0 > 50.0) {
				JOptionPane.showMessageDialog(null, "��ѡ��С�ڵ���50KB��ͼƬ�ļ���");
				return;
			}
			String picturePath = file.getAbsolutePath();
			//System.out.println(picturePath);
			Icon icon = new ImageIcon(picturePath);
			this.iamgeLb.setIcon(icon);
			this.imageLinkTxt.setText(picturePath);
		}
	}

	//���table��ĳһ���ײ�
	private void goodsTableMousePressed(java.awt.event.MouseEvent evt) {
		//��ȡѡ�е���
		int row = goodsTable.getSelectedRow();
		//�ڱ�����д��ѡ�е�����
		this.goodsIdTxt.setText((String) goodsTable.getValueAt(row, 0));
		this.goodsNameTxt.setText((String) goodsTable.getValueAt(row, 1));
		this.goodsDescTxt.setText((String) goodsTable.getValueAt(row, 2));
		this.priceTxt.setText((String) goodsTable.getValueAt(row, 3));
		this.imageLinkTxt.setText((String) goodsTable.getValueAt(row, 4));
		String picturePath = (String) goodsTable.getValueAt(row, 4);
		if (StringUtil.isNotEmpty(picturePath)) {
			Icon icon = new ImageIcon(picturePath);
			this.iamgeLb.setIcon(icon);
		} else {
			this.iamgeLb.setIcon(null);
		}
	}

	//��������
	private void jb_searchActionPerformed(java.awt.event.ActionEvent evt) {
		Goods goods = new Goods();
		String s_goodsName = this.s_goodsName.getText();
		String s_price1 = this.s_price_1.getText();
		String s_price2 = this.s_price_2.getText();
		if (StringUtil.isNotEmpty(s_price1)) {//price_1�ͼ۸�ǿ�
			if(!StringUtil.isNum(s_price1)){
				JOptionPane.showMessageDialog(null, "�����������ײͼ۸�Χ");
				return;
			}else{
				goods.setPrice1(Float.parseFloat(s_price1));
			}
		}
		if (StringUtil.isNotEmpty(s_price2)) {//price_2�߼۸�ǿ�
			if(!StringUtil.isNum(s_price2)){
				JOptionPane.showMessageDialog(null, "�����������ײͼ۸�Χ");
				return;
			}else{
				goods.setPrice(Float.parseFloat(s_price2));
			}
		}	 
		 if (StringUtil.isNotEmpty(s_price1) && StringUtil.isNotEmpty(s_price2)) {//����Ϊ�ǿ�
			if(goods.getPrice()<goods.getPrice1()){
				JOptionPane.showMessageDialog(null, "�����������ײͼ۸�Χ");
				return;
			}else if(goods.getPrice()==goods.getPrice1()){
				goods.setPrice(Float.parseFloat(s_price2));
			}
			else{
				goods.setPrice1(Float.parseFloat(s_price1));
				goods.setPrice(Float.parseFloat(s_price2));
				
			}
		} 
		 //����Ϊ������Ϊ��ѯ����
		goods.setGoodsName(s_goodsName);
		this.filltable(goods);
		System.out.println(goods.getPrice1());
		System.out.println(goods.getPrice());
			
	}

	private void resetValues() {
		this.goodsNameTxt.setText("");
		this.goodsDescTxt.setText("");
		this.priceTxt.setText("");
		this.imageLinkTxt.setText("");
		this.iamgeLb.setIcon(null);
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JTextArea goodsDescTxt;
	private javax.swing.JTextField goodsIdTxt;
	private javax.swing.JTextField goodsNameTxt;
	private javax.swing.JTable goodsTable;
	private javax.swing.JLabel iamgeLb;
	private javax.swing.JTextField imageLinkTxt;
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JButton jb_chooser;
	private javax.swing.JButton jb_delete;
	private javax.swing.JButton jb_modify;
	private javax.swing.JButton jb_search;
	private javax.swing.JTextField priceTxt;
	private javax.swing.JTextField s_goodsName;
	private javax.swing.JTextField s_price_1;
	private javax.swing.JTextField s_price_2;
	// End of variables declaration//GEN-END:variables

}
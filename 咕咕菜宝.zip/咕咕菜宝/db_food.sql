/*
Navicat MySQL Data Transfer

Source Server         : 向琦
Source Server Version : 50715
Source Host           : localhost:3306
Source Database       : db_food

Target Server Type    : MYSQL
Target Server Version : 50715
File Encoding         : 65001

Date: 2018-09-04 15:00:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `goods`
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `goodsName` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `goodsDesc` varchar(200) DEFAULT NULL,
  `imageLink` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', '宫保鸡丁', '20', '味道不错，欢迎点菜', 'C:\\Users\\MSI 105\\Desktop\\food\\宫保鸡丁.jpg');
INSERT INTO `goods` VALUES ('12', '青椒肉丝', '18', '下饭菜', 'C:\\Users\\MSI 105\\Desktop\\food\\青椒肉丝.jpg');
INSERT INTO `goods` VALUES ('13', '清炒蔬菜', '8', '一份解腻的青菜', 'C:\\Users\\MSI 105\\Desktop\\food\\清炒蔬菜.jpg');
INSERT INTO `goods` VALUES ('14', '黄焖鸡', '20', '', 'C:\\Users\\MSI 105\\Desktop\\food\\黄焖鸡.jpg');
INSERT INTO `goods` VALUES ('15', '糖醋里脊', '18', '喜欢酸甜口味的最好的选择', 'C:\\Users\\MSI 105\\Desktop\\food\\糖醋里脊.jpg');
INSERT INTO `goods` VALUES ('16', '回锅肉', '28', '四川家常菜，很下饭', 'C:\\Users\\MSI 105\\Desktop\\food\\回锅肉.jpg');
INSERT INTO `goods` VALUES ('17', '油炸花生米', '8', '下酒必备', 'C:\\Users\\MSI 105\\Desktop\\food\\油炸花生米.jpg');
INSERT INTO `goods` VALUES ('18', '辣炒粉条', '15', '', 'C:\\Users\\MSI 105\\Desktop\\food\\辣子炒粉条.jpg');
INSERT INTO `goods` VALUES ('19', '鱼香肉丝', '18', '很好吃的鱼香肉丝', 'C:\\Users\\MSI 105\\Desktop\\food\\鱼香肉丝.jpg');
INSERT INTO `goods` VALUES ('20', '凉拌耳丝', '15', '饭前开胃小菜', 'C:\\Users\\MSI 105\\Desktop\\food\\凉拌耳丝.jpg');

-- ----------------------------
-- Table structure for `order_goods`
-- ----------------------------
DROP TABLE IF EXISTS `order_goods`;
CREATE TABLE `order_goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderId` varchar(50) DEFAULT NULL,
  `goodsTotalPrice` float DEFAULT NULL,
  `goodsId` int(10) DEFAULT NULL,
  `goodsPrice` float DEFAULT NULL,
  `goodsNum` int(10) DEFAULT NULL,
  `goodsName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_order_goods_2` (`orderId`),
  KEY `FK_order_goods_1` (`goodsId`),
  CONSTRAINT `FK_order_goods_1` FOREIGN KEY (`goodsId`) REFERENCES `goods` (`id`),
  CONSTRAINT `FK_order_goods_2` FOREIGN KEY (`orderId`) REFERENCES `order_info` (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_goods
-- ----------------------------
INSERT INTO `order_goods` VALUES ('44', '20180904143839', '20', '1', '20', '1', '宫保鸡丁');
INSERT INTO `order_goods` VALUES ('45', '20180904143839', '18', '12', '18', '1', '青椒肉丝');
INSERT INTO `order_goods` VALUES ('46', '20180904144647', '18', '19', '18', '1', '鱼香肉丝');
INSERT INTO `order_goods` VALUES ('47', '20180904144647', '8', '17', '8', '1', '油炸花生米');
INSERT INTO `order_goods` VALUES ('48', '20180904144647', '15', '18', '15', '1', '辣炒粉条');
INSERT INTO `order_goods` VALUES ('49', '20180904144647', '28', '16', '28', '1', '回锅肉');

-- ----------------------------
-- Table structure for `order_info`
-- ----------------------------
DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
  `orderId` varchar(50) NOT NULL,
  `orderStatus` int(10) DEFAULT NULL,
  `orderNum` int(10) DEFAULT NULL,
  `orderTotalMoney` float DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_info
-- ----------------------------
INSERT INTO `order_info` VALUES ('20180904143839', '3', '2', '38', 'huli');
INSERT INTO `order_info` VALUES ('20180904144647', '1', '4', '69', 'huli');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userName` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `rank` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'admin', '123', null, '1');
INSERT INTO `user` VALUES ('2', 'xiangqi', 'sbsbsb', 'www.837860492@qq.com', '1');
INSERT INTO `user` VALUES ('11', '向琦', '123', '837860492@qq.com', '0');
INSERT INTO `user` VALUES ('12', 'huli', '666', '9958488@qq.com', '0');
